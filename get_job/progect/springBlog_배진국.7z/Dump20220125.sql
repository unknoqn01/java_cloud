-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 58.239.58.243    Database: java404_bjg_db
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `a`
--

DROP TABLE IF EXISTS `a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `a` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `send_id` varchar(45) NOT NULL,
  `recive_id` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `a`
--

LOCK TABLES `a` WRITE;
/*!40000 ALTER TABLE `a` DISABLE KEYS */;
INSERT INTO `a` VALUES (1,'b','a','aa','2022-01-18 09:45:09'),(2,'a','a','aa','2022-01-20 11:28:03'),(3,'a','a','aaa','2022-01-20 15:46:50'),(4,'','a','a','2022-01-20 17:43:57'),(5,'s','a','11','2022-01-24 14:59:29');
/*!40000 ALTER TABLE `a` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) NOT NULL,
  `title` varchar(45) NOT NULL,
  `contents` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `deleted_yn` char(1) DEFAULT 'N',
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (26,'a','제목','내용','2022-01-18 01:06:21','N'),(27,'b','제목','내용','2022-01-18 01:06:26','N'),(28,'c','제목','내용','2022-01-18 01:06:27','N'),(29,'d','제목a','내용','2022-01-18 01:06:28','N'),(30,'e','제목','내용','2022-01-18 01:06:30','N'),(31,'f','제목','내용','2022-01-18 01:06:31','N'),(32,'g','제목','내용','2022-01-18 01:06:33','N'),(33,'h','제목','내용','2022-01-18 01:06:35','N'),(34,'i','제목','내용','2022-01-18 01:06:37','N'),(35,'j','제목','내용','2022-01-18 01:06:38','N'),(36,'k','제목','내용','2022-01-18 01:06:40','N'),(37,'l','제목','내용','2022-01-18 01:06:41','N'),(38,'m','제목','내용','2022-01-18 01:06:42','N'),(39,'n','제목','내용','2022-01-18 01:06:44','N'),(40,'o','제목','내용','2022-01-18 01:06:46','N'),(41,'p','제목','내용','2022-01-18 01:06:47','N'),(42,'q','제목','내용','2022-01-18 01:06:49','N'),(43,'r','제목','내용','2022-01-18 01:06:50','N'),(45,'t','제목','내용','2022-01-18 01:06:53','N'),(46,'u','제목','내용','2022-01-18 01:06:55','N'),(47,'v','제목','내용','2022-01-18 01:06:56','N'),(48,'w','제목','내용','2022-01-18 01:06:58','N'),(49,'x','제목','내용','2022-01-18 01:06:59','N'),(50,'y','제목','내용','2022-01-18 01:07:01','N'),(51,'z','제목','내용','2022-01-18 01:07:02','N'),(52,'a','글 쓰기','aaa','2022-01-19 20:26:33','N'),(53,'a','ㅁ','ㅁ','2022-01-19 21:04:12','N'),(56,'d','aa','aa','2022-01-24 14:27:28','N');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `d`
--

DROP TABLE IF EXISTS `d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `d` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `send_id` varchar(45) NOT NULL,
  `recive_id` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `d`
--

LOCK TABLES `d` WRITE;
/*!40000 ALTER TABLE `d` DISABLE KEYS */;
/*!40000 ALTER TABLE `d` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `f`
--

DROP TABLE IF EXISTS `f`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `f` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `send_id` varchar(45) NOT NULL,
  `recive_id` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `f`
--

LOCK TABLES `f` WRITE;
/*!40000 ALTER TABLE `f` DISABLE KEYS */;
/*!40000 ALTER TABLE `f` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `g`
--

DROP TABLE IF EXISTS `g`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `g` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `send_id` varchar(45) NOT NULL,
  `recive_id` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `g`
--

LOCK TABLES `g` WRITE;
/*!40000 ALTER TABLE `g` DISABLE KEYS */;
/*!40000 ALTER TABLE `g` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) NOT NULL,
  `user_pw` varchar(45) NOT NULL,
  `user_phone` char(11) NOT NULL,
  `user_email` varchar(45) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (17,'a','11','11','abc@abc.com','2022-01-24 13:50:21'),(18,'d','11','11','11','2022-01-24 14:26:32'),(19,'f','f','11','11','2022-01-24 14:48:14'),(20,'g','jk90g6323l','1','1','2022-01-24 14:50:49');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg`
--

DROP TABLE IF EXISTS `msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `msg` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `send_id` varchar(45) NOT NULL,
  `recive_id` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg`
--

LOCK TABLES `msg` WRITE;
/*!40000 ALTER TABLE `msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s`
--

DROP TABLE IF EXISTS `s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `s` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `send_id` varchar(45) NOT NULL,
  `recive_id` varchar(45) NOT NULL,
  `msg` varchar(45) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`seq`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s`
--

LOCK TABLES `s` WRITE;
/*!40000 ALTER TABLE `s` DISABLE KEYS */;
INSERT INTO `s` VALUES (1,'s','s','s','2022-01-20 15:48:20');
/*!40000 ALTER TABLE `s` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'java404_bjg_db'
--

--
-- Dumping routines for database 'java404_bjg_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-25 11:38:02
