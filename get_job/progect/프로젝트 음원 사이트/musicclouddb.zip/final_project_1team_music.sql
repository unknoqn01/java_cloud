-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: final_project_1team
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `music`
--

DROP TABLE IF EXISTS `music`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `music` (
  `music_pk` int NOT NULL AUTO_INCREMENT,
  `music_category_pk` int NOT NULL,
  `user_pk` int NOT NULL,
  `music_title` varchar(45) NOT NULL,
  `music_artist` varchar(45) NOT NULL,
  `music_album` varchar(45) DEFAULT NULL,
  `music_desc` text,
  `like_count` int NOT NULL DEFAULT '0',
  `privacy` char(1) NOT NULL DEFAULT 'Y',
  `created_dt` datetime NOT NULL,
  PRIMARY KEY (`music_pk`),
  KEY `user_pk` (`user_pk`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `music`
--

LOCK TABLES `music` WRITE;
/*!40000 ALTER TABLE `music` DISABLE KEYS */;
INSERT INTO `music` VALUES (4,5,2,'Tea Time','Ofshane','Ofshane','Music without copyright - Attribution not required.\r\nYou\'re free to use this song and monetize your video.\r\nArtist: Ofshane | Track: Tea Time\r\nDownload MP3 - https://support.google.com/youtube/an...\r\nR&B & Soul | Romantic\r\nOfshane playlist: https://www.youtube.com/playlist?list...\r\nR&B & Soul music playlist: https://www.youtube.com/playlist?list...\r\nRomantic music playlist: https://www.youtube.com/playlist?list...\r\n\r\n#RnBSoulRomantic #Ofshane #TeaTime #NoCopyrightMusic #NoCopyrightAudioLibrary  #MusicVisualization #NCALIB\r\n\r\nSubscribe: https://www.youtube.com/c/ncalib?sub_...',11,'Y','2022-03-24 01:28:06'),(5,4,2,'Cavemen of the Future','Joel Cummins, Andy Farag','Joel Cummins, Andy Farag','No Copyright Music:\r\n\r\nJoel Cummins, Andy Farag - Cavemen of the Future\r\n\r\nYou’re free to use this song in any of your videos.\r\n\r\nImportant: Use only on YouTube!\r\n\r\nLIMO Recording Studio:\r\n• https://www.facebook.com/LIMO-Recordi...\r\n• https://twitter.com/KontaktLimo\r\n• https://www.youtube.com/user/MusicITVP\r\n\r\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\r\n\r\nDownload Photo: https://unsplash.com/photos/ccgXzYszcu8\r\n\r\n#LIMO #Music #Joel_Cummins',6,'Y','2022-03-24 01:30:22'),(6,4,2,'How\'s It Supposed to Feel (Instrumental)','NEFFEX','NEFFEX','Music without copyright - Attribution not required.\r\nDownload free and safe music for content creators (Free Music, No Copyright Music, Royalty-free Music, and Creative Commons). \r\n\r\nPlease subscribe! ❤️\r\nWe upload a new Music EVERY day: http://gestyy.com/eaBNbF\r\n\r\n? More free music:\r\n\r\nJoel Cummins Playlist: http://gestyy.com/eaBNks\r\nFreedom Trail Studio Playlist: http://gestyy.com/eaBNkH\r\nNico Staf Playlist: http://gestyy.com/eaBNk5\r\nNEFFEX Playlist: http://gestyy.com/eaBNlL\r\nRelaxing Music Playlist: http://gestyy.com/eaBNl8\r\nTrackTribe Playlist: http://gestyy.com/eaBNxq\r\nThe Mini Vandals Playlist: http://gestyy.com/eaBNxZ\r\nBrian Bolger Playlist: http://gestyy.com/eaBNc2\r\nFrench Fuse Playlist: http://gestyy.com/eaBNvA\r\nDivKid Playlist: http://gestyy.com/eaBNbg\r\n\r\n⚠️ You’re free to use this song in any of your YouTube videos.\r\n\r\n? Track Info:\r\n\r\nTitle: \r\nGenre: \r\nMood: \r\n\r\nEmail: Shehzarsifat1@gmail.com\r\n\r\n#NoCopyrightMusic #AudioLibrary #RoyaltyFreeMusic',7,'Y','2022-03-24 01:32:46');
/*!40000 ALTER TABLE `music` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-24 15:37:51
