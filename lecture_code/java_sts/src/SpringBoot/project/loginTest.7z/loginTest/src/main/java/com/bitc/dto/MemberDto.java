package com.bitc.dto;

import lombok.Data;

@Data
public class MemberDto {

	private String userId;
	private String userPw;
	private String userName;
	private String userEmail;
	private String userPhone;
	private String userAddr;
	private String userGender;
}
