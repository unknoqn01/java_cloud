package com.bitc.jkb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutsideFolderApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutsideFolderApplication.class, args);
	}

}
