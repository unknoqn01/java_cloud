package com.bitc.java404.dto;

import lombok.Data;

@Data
public class EmployeesDto {
	
	private int empNo;
	private String birthDate;
	private String firstName;
	private String lastName;
	private char gender;
	private String hireDate;
}
