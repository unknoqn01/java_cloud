package com.bitc.java404;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagingTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
