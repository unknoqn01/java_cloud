package com.bitc.dto;

import lombok.Data;

@Data
public class CalDto {

	private int result;
	private int num1;
	private int num2;
	private String operator;
}
