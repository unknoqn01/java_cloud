package com.bitc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjaxTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(AjaxTestApplication.class, args);
	}

}
