package com.bitc.dto;

import lombok.Data;

@Data
public class AreaDto {

	private String areaName;
}
