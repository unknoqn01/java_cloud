package com.bitc.csy.dto;

import lombok.Data;

@Data
public class AddrDto {

	private int seq;
	private String userId;
	private String userPw;
	private String userName;
	private String userEmail;
	private String userPhone;
	private String userAddr;
	private String userGender;
}
