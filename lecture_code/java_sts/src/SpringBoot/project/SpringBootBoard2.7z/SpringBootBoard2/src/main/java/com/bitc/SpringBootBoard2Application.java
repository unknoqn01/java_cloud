package com.bitc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBoard2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBoard2Application.class, args);
	}

}
