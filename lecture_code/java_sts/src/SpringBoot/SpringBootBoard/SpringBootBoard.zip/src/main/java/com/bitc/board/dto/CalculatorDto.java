package com.bitc.board.dto;

import lombok.Data;

@Data
public class CalculatorDto {

	private int num1;
	private int num2;
	private int result;
}
