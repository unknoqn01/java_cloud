package com.bitc.csy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAddressBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
