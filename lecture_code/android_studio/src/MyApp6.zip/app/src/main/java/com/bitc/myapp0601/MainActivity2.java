package com.bitc.myapp0601;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        RatingBar rtBar1 = findViewById(R.id.ratingbar1);
        RatingBar rtBar2 = findViewById(R.id.ratingbar2);
        RatingBar rtBar3 = findViewById(R.id.ratingbar3);

        Button btnUp = findViewById(R.id.btnUp);
        Button btnDown = findViewById(R.id.btnDown);

        btnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rtBar1.setRating(rtBar1.getRating() + rtBar1.getStepSize());
                rtBar2.setRating(rtBar2.getRating() + rtBar2.getStepSize());
                rtBar3.setRating(rtBar3.getRating() + rtBar3.getStepSize());
            }
        });

        btnDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rtBar1.setRating(rtBar1.getRating() - rtBar1.getStepSize());
                rtBar2.setRating(rtBar2.getRating() - rtBar2.getStepSize());
                rtBar3.setRating(rtBar3.getRating() - rtBar3.getStepSize());
            }
        });
    }
}