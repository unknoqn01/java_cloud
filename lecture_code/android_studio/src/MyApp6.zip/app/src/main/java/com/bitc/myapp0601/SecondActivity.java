package com.bitc.myapp0601;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SecondActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);

        Button btnReturn = findViewById(R.id.btnReturn);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                현재 액티비티를 종료
//                현재 액티비티가 종료되면 현재 액티비티를 호출한 액티비티로 되돌아감
                finish();
            }
        });
    }
}
