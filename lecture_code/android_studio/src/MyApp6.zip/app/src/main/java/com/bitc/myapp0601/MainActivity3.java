package com.bitc.myapp0601;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        setTitle("명화 선호도 투표");

//        투표 값을 저장할 배열
        final int voteCount[] = new int[9];
        for (int i = 0; i < voteCount.length; i++) {
            voteCount[i] = 0; // 기본값을 0으로 초기화
        }

//        이미지뷰의 배열 생성
//        아래에서 이미지 뷰에 각각 클릭 이벤트를 생성하기 위해서 배열로 만듬
        ImageView imageViews[] = new ImageView[9];
//        이미지 뷰의 id를 설정하기 위한 배열
        Integer imageIds[]  = {R.id.imgView1, R.id.imgView2, R.id.imgView3, R.id.imgView4, R.id.imgView5, R.id.imgView6, R.id.imgView7, R.id.imgView8, R.id.imgView9};
//        해당하는 이미지의 이름
        final String imgName[] = {"독서하는 소녀", "꽃장식 모자 소녀", "부채를 든 소녀", "이래느깡 단 베르양", "잠자는 소녀", "테라스의 두 자매", "피아노 레슨", "피아노 앞의 소녀들", "해변에서"};

        for (int i = 0; i < imageIds.length; i++) {
//             i는 지역 변수이기 때문에 View를 새로 생성 시 지역 변수를 찾지 못함
//            final 을 사용한 index에 i값을 대입하면 새로 생성한 View에서 index를 찾을 수 있음
            final int index; // 반드시 final이 필요
            index = i;

//            ImageView 타입의 객체를 9개 생성하여 연동함
//            각각의 ImageView에 이벤트 생성
            imageViews[index] = findViewById(imageIds[index]);
            imageViews[index].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    voteCount[index]++;
                    Toast.makeText(MainActivity3.this, ": 총 " + voteCount[index] + " 표", Toast.LENGTH_SHORT).show();
                }
            });
        }

        Button btnFinish = findViewById(R.id.btnResult);
        btnFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                표시할 액티비티 설정
                Intent intent = new Intent(getApplicationContext(), ResultActivity.class);
//                설정된 액티비티로 전송할 데이터 설정
                intent.putExtra("VoteCount", voteCount);
                intent.putExtra("ImageName", imgName);

                startActivity(intent);
            }
        });
    }
}