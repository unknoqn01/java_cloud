package com.bitc.myapp0601;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

// AppCompatActivity는 Activity 클래스를 상속받아 사용함
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioButton rdoSecond = findViewById(R.id.radioSecond);
        Button btnNewActivity = findViewById(R.id.btnNewActivity);
        btnNewActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;

                if (rdoSecond.isChecked() == true) {
                    intent = new Intent(getApplicationContext(), SecondActivity.class);
                }
                else {
                    intent = new Intent(getApplicationContext(), ThirdActivity.class);
                }
//                등록된 액티비티를 실행함
                startActivity(intent);
            }
        });
//        문제1) 화면을 총 5개 생성하여 라디오 버튼을 클릭했을 경우 해당 액티비티를 여는 프로그램을 작성하세요
        RadioGroup rdoGroup2 = findViewById(R.id.radioGroup2);
        Button btnNewAct2 = findViewById(R.id.btnNewActivity2);
        btnNewAct2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                int rdoBtn = rdoGroup2.getCheckedRadioButtonId();

                switch (rdoBtn) {
                    case R.id.rdoAct1:
                        intent = new Intent(getApplicationContext(), Ex1Activity.class);
                        break;

                    case R.id.rdoAct2:
                        intent = new Intent(getApplicationContext(), Ex2Activity.class);
                        break;

                    case R.id.rdoAct3:
                        intent = new Intent(getApplicationContext(), Ex3Activity.class);
                        break;

                    case R.id.rdoAct4:
                        intent = new Intent(getApplicationContext(), Ex4Activity.class);
                        break;

                    default:
                        intent = new Intent(getApplicationContext(), Ex5Activity.class);
                        break;
                }
                startActivity(intent);
            }
        });
    }
}