package com.bitc.myapp0601;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CalculatorResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator_result);
        setTitle("세컨드 액티비티");

//        인텐트 정보 가져오기
        Intent inIntent = getIntent();
//        int 타입으로 데이터를 가져옴
        int num1 = inIntent.getIntExtra("Num1", 0);
        int num2 = inIntent.getIntExtra("Num2", 0);
        final int hapValue = num1 + num2;

        TextView tv1 = findViewById(R.id.tv1);
        tv1.setText(String.valueOf(hapValue)); // 결과값 표시s

        Button btnReturn = findViewById(R.id.btnReturn);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                데이터 전송을 위한 인텐트 생성
//                데이터 전송 위치를 현재 액티비티를 호출한 액티비티로 설정
                Intent outIntent = new Intent(getApplicationContext(), MainActivity4.class);

                outIntent.putExtra("Hap", hapValue);
//                해당 액티비티가 종료된 후 해당 액티비티를 호출한 액티비티에 전송되는 resultCode설정
                setResult(RESULT_OK, outIntent);
                finish(); // 현재 액티비티 종료
            }
        });

    }
}