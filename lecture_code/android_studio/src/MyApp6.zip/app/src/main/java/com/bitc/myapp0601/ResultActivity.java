package com.bitc.myapp0601;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        setTitle("투표 결과");

//        Intent 객체를 생성하고 getIntent()로 Intent 정보를 받아옴
        Intent intent = getIntent();
        int[] voteResult = intent.getIntArrayExtra("VoteCount");
        String[] imgName = intent.getStringArrayExtra("ImageName");

//        UI의 TextView와 RatingBar를 한번에 연동하기 위해 배열로 생성
        TextView[] tViews = new TextView[imgName.length];
        RatingBar[] rtBars = new RatingBar[imgName.length];

//        UI의 TextView와 RatingBar의 ID를 배열로 생성
        Integer[] tViewId = {R.id.tView1, R.id.tView2, R.id.tView3, R.id.tView4, R.id.tView5, R.id.tView6, R.id.tView7, R.id.tView8, R.id.tView9};
        Integer[] rtBarId = {R.id.rtBar1, R.id.rtBar2, R.id.rtBar3, R.id.rtBar4, R.id.rtBar5, R.id.rtBar6, R.id.rtBar7, R.id.rtBar8, R.id.rtBar9};

//        for문을 사용하여 UI와 자바 코드 부분은 연동
        for (int i = 0; i < voteResult.length; i++) {
            tViews[i] = findViewById(tViewId[i]);
            rtBars[i] = findViewById(rtBarId[i]);

            tViews[i].setText(imgName[i]);
            rtBars[i].setRating((float) voteResult[i]);
        }

//        for문을 사용하여 TextView의 text와 RatingBar의 rating 값을 한번에 입력
//        for (int i = 0; i < voteResult.length; i++) {
//            tViews[i].setText(imgName[i]);
//            rtBars[i].setRating((float) voteResult[i]);
//        }

        Button btnReturn = findViewById(R.id.btnReturn);
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}