package com.bitc.java404.dto;

import lombok.Data;

@Data
public class UserDto {

	private String userId;
	private String userPw;
	private String userEmail;
}
