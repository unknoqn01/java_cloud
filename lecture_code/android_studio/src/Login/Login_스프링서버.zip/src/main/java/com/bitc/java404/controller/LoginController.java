package com.bitc.java404.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bitc.java404.dto.UserDto;
import com.bitc.java404.service.LoginService;
import com.google.gson.Gson;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@RequestMapping("/")
	public String index() throws Exception {
		return "index";
	}
	
	@ResponseBody
	@RequestMapping(value="/Login", method=RequestMethod.POST)
	public String loginPost(UserDto user) throws Exception {
		
		int count = loginService.getUserInfo(user);
		Map<String, String> result = new HashMap<String, String>();
		
		if (count == 1) {
			user = loginService.getUser(user);
			result.put("success", "true");
			result.put("userId", user.getUserId());
			result.put("userPw", user.getUserPw());
		}
		else {
			result.put("success", "false");
		}
		
		Gson gson = new Gson();
		
		return gson.toJson(result);
	}
	
	@ResponseBody
	@RequestMapping("Register")
	public String register(UserDto user) throws Exception {
		
		int userYn = loginService.getUserInfoYn(user.getUserId());
		Map<String, String> result = new HashMap<String, String>();
		
		if (userYn <= 0) {
			if (loginService.insertUser(user) > 0) {
				result.put("success", "true");
			}
			else {
				result.put("success", "false");
			}
		}
		else {
			result.put("success", "false");
		}
		
		Gson gson = new Gson();
		
		return gson.toJson(result);
	}
	
}
