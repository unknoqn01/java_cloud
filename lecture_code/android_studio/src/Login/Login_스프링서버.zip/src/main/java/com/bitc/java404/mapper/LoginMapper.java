package com.bitc.java404.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.bitc.java404.dto.UserDto;

@Mapper
public interface LoginMapper {

	int getUserInfo(UserDto user) throws Exception;

	UserDto getUser(UserDto user) throws Exception;

	int getUserInfoYn(String userId) throws Exception;

	int insertUser(UserDto user) throws Exception;
}
