package com.bitc.java404.service;

import com.bitc.java404.dto.UserDto;

public interface LoginService {

	int getUserInfo(UserDto user) throws Exception;

	UserDto getUser(UserDto user) throws Exception;

	int getUserInfoYn(String userId) throws Exception;

	int insertUser(UserDto user) throws Exception;
}
