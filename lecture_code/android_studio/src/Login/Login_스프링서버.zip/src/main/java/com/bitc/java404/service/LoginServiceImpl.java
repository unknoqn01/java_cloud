package com.bitc.java404.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bitc.java404.dto.UserDto;
import com.bitc.java404.mapper.LoginMapper;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginMapper loginMapper;

	@Override
	public int getUserInfo(UserDto user) throws Exception {
		
		return loginMapper.getUserInfo(user);
	}

	@Override
	public UserDto getUser(UserDto user) throws Exception {
		return loginMapper.getUser(user);
	}

	@Override
	public int getUserInfoYn(String userId) throws Exception {
		return loginMapper.getUserInfoYn(userId);
	}

	@Override
	public int insertUser(UserDto user) throws Exception {
		return loginMapper.insertUser(user);
	}

	
	
}
