package com.bitc.myapp0801;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

public class SubActivity3 extends AppCompatActivity {

    ProgressBar pb1;
    Button btnInc;
    Button btnDec;
    TextView tvSeek;
    SeekBar sb1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub3);
        setTitle("프로그레스바, 시크바 사용하기");

        pb1 = findViewById(R.id.progress1);
        btnInc = findViewById(R.id.btnInc);
        btnDec = findViewById(R.id.btnDec);

        btnInc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pb1.incrementProgressBy(10);
            }
        });

        btnDec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pb1.incrementProgressBy(-10);
            }
        });

        tvSeek = findViewById(R.id.tvSeekBar1);
        sb1 = findViewById(R.id.seekBar1);
        
        sb1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//            2번째 매개변수가 SeekBar의 변경된 값
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tvSeek.setText("진행율 : " + i + " %");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}