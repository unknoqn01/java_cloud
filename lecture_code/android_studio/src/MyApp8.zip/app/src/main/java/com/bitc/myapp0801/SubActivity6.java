package com.bitc.myapp0801;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class SubActivity6 extends AppCompatActivity {

    ListView lvMP3;
    Button btnPlay;
    Button btnStop;
    TextView tvMP3;
    TextView tvTime;
    SeekBar sbMP3;

    ArrayList<String> mp3List; // 음악파일 리스트
    String selectMP3; // 현재 선택된 파일

//    파일 경로 가져오기
    String mp3Path = Environment.getExternalStorageDirectory().getPath() + "/";
    MediaPlayer mPlayer; // 음악 파일 재생

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub6);
        setTitle("UI 스레드를 사용한 MP3 플레이어");

//        외부 저장소에 저장된 파일를 사용하기위한 권한 요청
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, MODE_PRIVATE);

        mp3List = new ArrayList<String>();

//        실제 파일이 있는 경로의 디렉토리 및 파일 리스트를 가져옴
        File[] listFiles = new File(mp3Path).listFiles();
        String fileName;
        String extName;

        for (File file : listFiles) {
            fileName = file.getName(); // 파일명 가져오기
            extName = fileName.substring(fileName.length() - 3); // 확장자명 가져오기

//            mp3인 확장자만 선택
            if (extName.equals((String) "mp3")) {
                mp3List.add(fileName); // 음악 파일 리스트에 저장
            }
        }

        lvMP3 = findViewById(R.id.lvMP3);
//        리스트 뷰에 ArrayAdapter 연동 설정
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, mp3List);
        lvMP3.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lvMP3.setAdapter(adapter); // 실제 데이터 리스트뷰에 적용
        lvMP3.setItemChecked(0, true); // 기본 선택된 항목 설정
        lvMP3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // 리스트 뷰에서 클릭한 것을 현재 선택한 파일로 설정
                selectMP3 = mp3List.get(i);
            }
        });

        selectMP3 = mp3List.get(0); // 미 클릭 시 기본 선택된 파일

        btnPlay = findViewById(R.id.btnPlay);
        btnStop = findViewById(R.id.btnStop);
        tvMP3 = findViewById(R.id.tvMP3);
        sbMP3 = findViewById(R.id.sbMP3);
        tvTime = findViewById(R.id.tvTime);

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    mPlayer = new MediaPlayer();
//                    실제 파일 경로를 통해서 파일을 MediaPlayer 객체에 등록
                    mPlayer.setDataSource(mp3Path + selectMP3);
                    mPlayer.prepare();
                    mPlayer.start(); // 음악파일 재생

                    btnPlay.setClickable(false);
                    btnStop.setClickable(true);

                    tvMP3.setText("실행중인 음악 : " + selectMP3);

//                    UI 변경을 위해서 스레드를 사용
                    new Thread() {
                        SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss");

                        public void run() {
                            if (mPlayer == null) {
                                return;
                            }

//                            SeekBar의 최대값을 MediaPlayer객체에 설정된 파일의 크기만큼으로 설정
                            sbMP3.setMax(mPlayer.getDuration());

//                            현재 재생중인지 확인
                            while (mPlayer.isPlaying()) {
//                                UI 전용 스레드를 실행하여 UI를 변경
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
//                                        현재 재생중인 위치를 가져와서 SeekBar에 적용
                                        sbMP3.setProgress(mPlayer.getCurrentPosition());
//                                        현재 재생중인 위치를 가져와서 재생 시간을 표시
                                        tvTime.setText("진행 시간 : " + timeFormat.format(mPlayer.getCurrentPosition()));
                                    }
                                });
                                SystemClock.sleep(100);
                            }
                        }
                    }.start();
                }
                catch (IOException e) {

                }
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mPlayer.stop();
                mPlayer.reset();

                btnPlay.setClickable(true);
                btnStop.setClickable(false);

                tvMP3.setText("실행중인 음악 : " );
                sbMP3.setProgress(0);
                tvTime.setText("진행 시간 : ");
            }
        });
        btnStop.setClickable(false);
    }
}