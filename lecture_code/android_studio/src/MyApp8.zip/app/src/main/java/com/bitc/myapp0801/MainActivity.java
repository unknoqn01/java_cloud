package com.bitc.myapp0801;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaParser;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    Button btnMp3Play;
    Button btnMusicPlayer;
    Button btnPrgSeek;
    Button btnThread;
    Button btnUIThread;
    Button btnMusicPlayer2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("13장");

        btnMp3Play = findViewById(R.id.btnMp3Play);
        btnMp3Play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity1.class);
                startActivity(intent);
            }
        });

        btnMusicPlayer = findViewById(R.id.btnMusicPlayer);
        btnMusicPlayer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity2.class);
                startActivity(intent);
            }
        });

        btnPrgSeek = findViewById(R.id.btnPrgSeek);
        btnPrgSeek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity3.class);
                startActivity(intent);
            }
        });

        btnThread = findViewById(R.id.btnThread);
        btnThread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity4.class);
                startActivity(intent);
            }
        });

        btnUIThread = findViewById(R.id.btnUIThread);
        btnUIThread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity5.class);
                startActivity(intent);
            }
        });

        btnMusicPlayer2 = findViewById(R.id.btnMusicPlayer2);
        btnMusicPlayer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SubActivity6.class);
                startActivity(intent);
            }
        });
    }
}