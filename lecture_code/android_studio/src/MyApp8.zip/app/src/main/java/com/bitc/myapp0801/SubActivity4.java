package com.bitc.myapp0801;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class SubActivity4 extends AppCompatActivity {

    SeekBar sb1;
    SeekBar sb2;
    Button btnSeekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub4);

        sb1 = findViewById(R.id.sb1);
        sb2 = findViewById(R.id.sb2);
        btnSeekBar = findViewById(R.id.btnSeekBar);

        btnSeekBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                기본 쓰레드가 for문을 완료하고 난 후 UI를 업데이트 시킴
//                for (int i = 0; i < 100; i++) {
//                    sb1.setProgress(sb1.getProgress() + 2);
//                    sb2.setProgress(sb2.getProgress() + 1);
//                    SystemClock.sleep(50);
//                }

//                new Thread() {
//                    public void run() {
//                        for (int i = 0; i < 100; i++) {
//                            sb1.setProgress(sb1.getProgress() + 2);
//                            sb2.setProgress(sb2.getProgress() + 1);
//                            SystemClock.sleep(50);
//                        }
//                    }
//                }.start();

//                쓰레드를 추가하여 각각의 SeekBar의 값을 변경함
//                기본 쓰레드가 UI를 업데이트 시킴
                new Thread() {
                    public void run() {
                        for (int i = sb1.getProgress(); i < 100; i++) {
                            sb1.setProgress(sb1.getProgress() + 2);
                            SystemClock.sleep(50);
                        }
                    }
                }.start();

                new Thread() {
                    public void run() {
                        for (int i = sb2.getProgress(); i < 100; i++) {
                            sb2.setProgress(sb2.getProgress() + 1);
                            SystemClock.sleep(50);
                        }
                    }
                }.start();
            }
        });
    }
}