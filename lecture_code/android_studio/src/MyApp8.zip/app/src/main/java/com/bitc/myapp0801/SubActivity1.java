package com.bitc.myapp0801;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;

public class SubActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub1);
        setTitle("음악 파일 재생");

        final MediaPlayer mediaPlayer;
        mediaPlayer = MediaPlayer.create(this, R.raw.song1);

        final Switch switch1 = findViewById(R.id.switch1);

        switch1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (switch1.isChecked() == true) {
                    mediaPlayer.start();
                }
                else {
                    mediaPlayer.stop();
                }
            }
        });
    }
}