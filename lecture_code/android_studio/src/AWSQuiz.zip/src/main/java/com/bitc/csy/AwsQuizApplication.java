package com.bitc.csy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsQuizApplication.class, args);
	}

}
