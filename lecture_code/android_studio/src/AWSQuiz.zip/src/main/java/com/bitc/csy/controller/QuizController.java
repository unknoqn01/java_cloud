package com.bitc.csy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bitc.csy.dto.UserDto;
import com.bitc.csy.service.QuizService;

@Controller
public class QuizController {

	@Autowired
	private QuizService quizService;
	
	@RequestMapping("/")
	public String index() throws Exception {
		return "index";
	}
	
	@RequestMapping("quiz")
	public ModelAndView quiz() throws Exception {
		ModelAndView mv = new ModelAndView("quiz");
		
		UserDto user = quizService.selectUser();
		mv.addObject("user", user);
		
		return mv;
	}
}
