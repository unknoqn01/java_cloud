package com.bitc.csy.dto;

import lombok.Data;

@Data
public class UserDto {

	private String userId;
	private String userPw;
	private String userEmail;
}
