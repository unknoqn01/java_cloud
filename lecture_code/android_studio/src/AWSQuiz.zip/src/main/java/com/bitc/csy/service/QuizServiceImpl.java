package com.bitc.csy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bitc.csy.dto.UserDto;
import com.bitc.csy.mapper.QuizMapper;

@Service
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizMapper quizMapper;
	
	@Override
	public UserDto selectUser() throws Exception {
		return quizMapper.selectUser();
	}

}
