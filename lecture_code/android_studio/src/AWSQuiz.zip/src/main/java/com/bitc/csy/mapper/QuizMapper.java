package com.bitc.csy.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.bitc.csy.dto.UserDto;

@Mapper
public interface QuizMapper {

	UserDto selectUser() throws Exception;
}
