package com.bitc.csy.service;

import com.bitc.csy.dto.UserDto;

public interface QuizService {

	UserDto selectUser() throws Exception;

	

}
