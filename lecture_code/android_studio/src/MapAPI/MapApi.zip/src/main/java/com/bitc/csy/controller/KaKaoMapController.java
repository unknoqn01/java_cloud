package com.bitc.csy.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class KaKaoMapController {

	@RequestMapping(value="/", method=RequestMethod.GET)
	public String index() throws Exception {
		return "index";
	}
	
	@RequestMapping(value="kakao/map", method=RequestMethod.GET)
	public String kakaoMap() throws Exception {
		return "/kakao/kakaomap";
	}
}
