package com.bitc.csy.mygooglemaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.runtime.Permission;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    SupportMapFragment mapFragment;
    GoogleMap gMap;

    MarkerOptions myLocationMarker;

    Button btnPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        xml에 있는 지도 화면 부분을 가져옴
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
//        구글 맵 호출하여 연동
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(@NonNull GoogleMap googleMap) {
                Log.d("map", "구글 맵 준비 완료");
                gMap = googleMap;

//                gMap.setMyLocationEnabled(true);
            }
        });

//        지도 초기화
        try {
            MapsInitializer.initialize(this);
        }
        catch (Exception e) {
            Log.d("오류 : ", e.getStackTrace().toString());
            e.printStackTrace();
        }

//        위험한 권한 사용에 대한 요청 부분
        AndPermission.with(this)
                .runtime()
                .permission(Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION)
                .onGranted(new Action<List<String>>() {
                    @Override
                    public void onAction(List<String> data) {
                        showToast("허용된 권한 수 : " + data.size());
                    }
                })
                .onDenied(new Action<List<String>>() {
                    @Override
                    public void onAction(List<String> data) {
                        showToast("거부된 권한 수 : " + data.size());
                    }
                })
                .start();

        btnPosition = findViewById(R.id.btnPosition);
        btnPosition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                현재 위치 불러오기
                startLocationService();
            }
        });
    }

    public void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

//    버튼 클릭 시 현재 위치로 맵 이동
    public void startLocationService() {
//        현재 위치 정보를 시스템에서 받아옴
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        try {
//            마지막 위치 가져오기
//            gps를 통해서 가져옴
            Location location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

            if (location != null) {
//                위도 정보 가져오기
                double lat = location.getLatitude();
//                경도 정보 가져오기
                double lng = location.getLongitude();
                String msg = "최근 위치 : \nLat :  " + lat + "\nLng : " + lng;
                Log.d("map : ", msg);
            }

//            LocationListener를 상속받아 구현한 GPSListener
            GPSListener gpsListener = new GPSListener();
            long minTime = 10000;
            float minDistance = 0;

//            위치 정보를 업데이트 함
//            매개변수 : 위치 정보를 가져올 방식, 호출 주기 시간, 위치 변경 시 호출 거리, 위치 변경 시 동작할 이벤트 리스너
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, minDistance, gpsListener);

            Toast.makeText(getApplicationContext(), "현재 위치 확인 요청", Toast.LENGTH_SHORT).show();
        }
        catch (SecurityException e) {
            Log.d("오류 : ", e.getStackTrace().toString());
            e.printStackTrace();
        }
    }

//    반복해서 위치 정보를 가져와야 할 경우 LocationListener를 사용하여 반복해서 가져옴
    class GPSListener implements LocationListener {

        @Override
        public void onLocationChanged(@NonNull Location location) {
            double lat = location.getLatitude();
            double lng = location.getLongitude();

            String msg = "내 위치 : \nLat : " + lat + "\nLng : " + lng;
            Log.d("map", msg);

            showCurrentLocation(lat, lng);
        }
    }

//    현재 위치로 카메라 이동 및 줌 단계 설정
    private void showCurrentLocation(double lat, double lng) {
//        현재 좌표값 받기
        LatLng curPoint = new LatLng(lat, lng);
        gMap.animateCamera(CameraUpdateFactory.newLatLngZoom(curPoint, 16));

//        마커 추가하기
        showMyLocationMarker(curPoint);
    }

//    마커 찍기
    private void showMyLocationMarker(LatLng curPoint) {
        if (myLocationMarker == null) {
            myLocationMarker = new MarkerOptions();
            myLocationMarker.position(curPoint);
            myLocationMarker.title("현재 위치\n");
            myLocationMarker.snippet("GPS로 확인한 위치");
            myLocationMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.mylocation));
            gMap.addMarker(myLocationMarker);
        }
        else {
            myLocationMarker.position(curPoint);
        }
    }
}