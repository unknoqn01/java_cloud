package com.bitc.myapp1001;

public class Movie {

    String rnum;
    String rank;
    String rankInten;
    String rankOldAndNew;
    String movieCd;
    String movieNm;
    String openDt;
    String salesAmt;
    String salesInten;
    String salesChange;
    String salesAcc;
    String audiCnt;
    String audiIntent;
    String audiChange;
    String audiAcc;
    String scrnCnt;
    String showCnt;
}
