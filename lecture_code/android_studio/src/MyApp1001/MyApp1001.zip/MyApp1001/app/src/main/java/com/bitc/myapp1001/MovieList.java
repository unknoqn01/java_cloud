package com.bitc.myapp1001;

public class MovieList {
    MovieListResult boxOfficeResult;
}
