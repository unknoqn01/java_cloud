package com.bitc.myapppush.androidteam2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ReviewWrite extends AppCompatActivity {

    final private String TAG = getClass().getSimpleName();


    EditText titleEdit, reviewEdit;
    Button okButton;

    // 유저아이디변수
    String userid = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_write);

        userid = getIntent().getStringExtra("userid");

        titleEdit = findViewById(R.id.titleEdit);
        reviewEdit = findViewById(R.id.reviewEdit);
        okButton = findViewById(R.id.okButton);

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


            }
        });
    }
}