package com.bitc.myapppush.androidteam2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.RecyclerViewHolders> {
    ArrayList<Movie> items;
    LayoutInflater inflater;
    Context context;

    public MovieAdapter(Context context, ArrayList<Movie> items) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.items = items;
    }

    @NonNull
    @Override
    public RecyclerViewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.recycle_list_item, parent, false);
        RecyclerViewHolders viewHolder = new RecyclerViewHolders(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewHolders holder, int position) {
        // TMDB에서 이미지를 받아오는 주소
        String url = "https://image.tmdb.org/t/p/w500" + items.get(position).getPoster_path();
        //  글라이드는 안드로이드에서 이미지를 빠르고 효율적으로 불러올 수 있게 도와주는 라이브러리
        Glide.with(context)
                .load(url)
                .into(holder.imageView);

        Movie item = items.get(position);
        holder.setItem(item);

        final int location = position;

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, MovieDetail.class);
                intent.putExtra("title", items.get(location).getTitle());
                intent.putExtra("original_title", items.get(location).getOriginal_title());
                intent.putExtra("poster_path", items.get(location).getPoster_path());
                intent.putExtra("overview", items.get(location).getOverview());
                intent.putExtra("release_date", items.get(location).getRelease_date());
                intent.putExtra("vote_average", items.get(location).getVote_average());
                intent.putExtra("genre_ids", items.get(location).getGenre_ids());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public void addItem(Movie item) {
        items.add(item);
    }

    public void setItems(ArrayList<Movie> items) {
        this.items = items;
    }


    static class RecyclerViewHolders extends RecyclerView.ViewHolder {
        ImageView imageView;
        //TextView textView;

        public RecyclerViewHolders(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.mainPoster);
            //textView = itemView.findViewById(R.id.tvTitle);
        }

        public void setItem(Movie item) {
            //textView.setText(item.getTitle());
        }
    }
}
