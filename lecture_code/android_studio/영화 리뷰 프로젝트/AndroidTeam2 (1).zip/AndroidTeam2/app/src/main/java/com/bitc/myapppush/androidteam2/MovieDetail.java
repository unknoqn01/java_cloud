package com.bitc.myapppush.androidteam2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MovieDetail extends AppCompatActivity {

    private ImageView detail_poster;
    private TextView detail_title;
    private TextView detail_originalTitle;
    private TextView detail_releaseDate;
    private RatingBar detail_voteAverage;
    private TextView detail_textVoteAverage;
    private TextView detail_overview;
    private TextView detail_genre;
    private FloatingActionButton menu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_movie);

        // 뒤로가기 버튼
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        menu = findViewById(R.id.menu);
        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Menu.class);
                startActivity(intent);
            }
        });

        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String original_title = intent.getStringExtra("original_title");
        String release_date = intent.getStringExtra("release_date");
        String poster_path = "https://image.tmdb.org/t/p/w500" + intent.getStringExtra("poster_path");
        String vote_average = intent.getStringExtra("vote_average");
        String overview = intent.getStringExtra("overview");
        int[] genre = intent.getIntArrayExtra("genre_ids");

        float average = Float.parseFloat(vote_average) / 2;

        detail_poster = findViewById(R.id.detail_poster);
        detail_title = findViewById(R.id.detail_title);
        detail_originalTitle = findViewById(R.id.detail_originalTitle);
        detail_voteAverage = findViewById(R.id.detail_voteAverage);
        detail_textVoteAverage = findViewById(R.id.textVoteAverage);
        detail_releaseDate = findViewById(R.id.detail_releaseDate);
        detail_overview = findViewById(R.id.detail_overview);
        detail_genre = findViewById(R.id.detail_genre);


        Glide.with(this)
                .load(poster_path)
                .into(detail_poster);
        detail_title.setText(title);
        detail_originalTitle.setText(original_title);
        detail_releaseDate.setText(release_date);
        detail_voteAverage.setRating(average);
        detail_textVoteAverage.setText("("+vote_average+")");
        detail_overview.setText(overview);

        for (int i = 0; i< genre.length; i++) {
            switch (genre[i]) {
                case 28:
                    detail_genre.append(" 액션");
                    break;
                case 12:
                    detail_genre.append(" 모험");
                    break;
                case 16:
                    detail_genre.append(" 애니메이션");
                    break;
                case 35:
                    detail_genre.append(" 코미디");
                    break;
                case 80:
                    detail_genre.append(" 범죄");
                    break;
                case 99:
                    detail_genre.append(" 다큐멘터리");
                    break;
                case 18:
                    detail_genre.append(" 드라마");
                    break;
                case 10751:
                    detail_genre.append(" 가족");
                    break;
                case 14:
                    detail_genre.append(" 판타지");
                    break;
                case 36:
                    detail_genre.append(" 역사");
                    break;
                case 27:
                    detail_genre.append(" 공포");
                    break;
                case 10402:
                    detail_genre.append(" 음악");
                    break;
                case 9648:
                    detail_genre.append(" 미스터리");
                    break;
                case 10749:
                    detail_genre.append(" 로맨스");
                    break;
                case 878:
                    detail_genre.append(" SF");
                    break;
                case 10770:
                    detail_genre.append(" TV영화");
                    break;
                case 53:
                    detail_genre.append(" 스릴러");
                    break;
                case 10752:
                    detail_genre.append(" 전쟁");
                    break;
                case 37:
                    detail_genre.append(" 서부");
                    break;
            }
        }

        setTitle(title);

        Button review = findViewById(R.id.review);

        review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), ReviewActivity.class);
                startActivity(intent);
            }
        });

    }
}
