package com.bitc.myapp4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        setTitle("애완동물 사진 보기");

        TextView text2 = findViewById(R.id.text2);
        CheckBox chkAgree = findViewById(R.id.chkAgree);
        RadioGroup rGroup = findViewById(R.id.rGroup);
        RadioButton rBtnDog = findViewById(R.id.rBtnDog);
        RadioButton rBtnCat = findViewById(R.id.rBtnCat);
        RadioButton rBtnRabbit = findViewById(R.id.rBtnRabbit);
        Button btnOK = findViewById(R.id.btnOk);
        ImageView imgPet = findViewById(R.id.imgPet);

        chkAgree.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (chkAgree.isChecked() == true) {
                    text2.setVisibility(View.VISIBLE);
                    rGroup.setVisibility(View.VISIBLE);
                    btnOK.setVisibility(View.VISIBLE);
                    imgPet.setVisibility(View.VISIBLE);
                }
                else {
                    text2.setVisibility(View.INVISIBLE);
                    rGroup.setVisibility(View.INVISIBLE);
                    btnOK.setVisibility(View.INVISIBLE);
                    imgPet.setVisibility(View.INVISIBLE);
                }
            }
        });

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (rGroup.getCheckedRadioButtonId()) {
                    case R.id.rBtnDog:
                        imgPet.setImageResource(R.drawable.dog);
                        break;

                    case R.id.rBtnCat:
                        imgPet.setImageResource(R.drawable.cat);
                        break;

                    case R.id.rBtnRabbit:
                        imgPet.setImageResource(R.drawable.rabbit);
                        break;
                }
            }
        });
    }
}